Config = {}

Config.Locale = 'es'

Config.EnableCash       = true  -- permitir robar dinero
Config.EnableBlackMoney = true  -- permitir robar dinero negro
Config.EnableInventory  = true  -- permitir robar inventario