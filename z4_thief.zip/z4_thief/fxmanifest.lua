fx_version 'adamant'

game 'gta5'

description 'Z4 THIEF @Z4TOMIC'

version '1.0.2'

client_scripts {
  '@es_extended/locale.lua',
  'locales/br.lua',
  'locales/en.lua',
  'locales/fr.lua',
  'locales/sv.lua',
  'locales/pl.lua',
  'config.lua',
  'client/main.lua',
  'handsup.lua'
}

server_scripts {
  '@es_extended/locale.lua',
  'locales/br.lua',
  'locales/en.lua',
  'locales/fr.lua',
  'locales/sv.lua',
  'locales/pl.lua',
  'config.lua',
  'server/main.lua'
}
